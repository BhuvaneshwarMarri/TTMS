Drop Table If Exists Hotel;
Create Table Hotel(
    Hotel_id int primary key,
    Hotel_name varchar(50),
    Hotel_email varchar(50),
    Hotel_phone bigint,
    Hotel_address varchar(250),
    Hotel_city varchar(250),
    Hotel_image varchar(250),
    Hotel_room_image varchar(250),
    Hotel_amenities varchar(250),
    Hotel_stars int,
    Hotel_ratings_avg decimal(2,1),
    Hotel_pcomments text,
    Hotel_ncomments text,
    Hotel_description text
)Engine=InnoDb Default Charset=latin1;
replace Into Hotel (Hotel_id, Hotel_name, Hotel_email, Hotel_phone, Hotel_address, Hotel_city, Hotel_image, Hotel_room_image, Hotel_amenities, Hotel_stars, Hotel_ratings_avg)
Values
(1, 'Grand Plaza', 'info@grandplaza.com', 1234567890, '123 Main St', 'Metropolis', 'grandplaza.jpg', 'room1.jpg', 'Pool, Gym, Spa', 5, 4.5),
(2, 'Ocean View', 'contact@oceanview.com', 2345678901, '456 Beach Rd', 'Seaside', 'oceanview.jpg', 'room2.jpg', 'Beach Access, Free Breakfast', 4, 4.2),
(3, 'Mountain Retreat', 'stay@mountainretreat.com', 3456789012, '789 Hilltop Ln', 'Highland', 'mountainretreat.jpg', 'room3.jpg', 'Hiking Trails, Fireplace', 4, 4.7),
(4, 'City Central', 'hello@citycentral.com', 4567890123, '101 Downtown Ave', 'Urbantown', 'citycentral.jpg', 'room4.jpg', 'Free WiFi, Parking', 3, 3.8),
(5, 'Lakeside Inn', 'reservations@lakesideinn.com', 5678901234, '202 Lakeview Dr', 'Laketown', 'lakesideinn.jpg', 'room5.jpg', 'Lake View, Fishing', 4, 4.3),
(6, 'Desert Oasis', 'info@desertoasis.com', 6789012345, '303 Desert Rd', 'Sandyville', 'desertoasis.jpg', 'room6.jpg', 'Pool, Desert Tours', 5, 4.6),
(7, 'Forest Lodge', 'contact@forestlodge.com', 7890123456, '404 Forest Path', 'Woodland', 'forestlodge.jpg', 'room7.jpg', 'Nature Walks, Fireplace', 4, 4.4),
(8, 'Urban Escape', 'stay@urbanescape.com', 8901234567, '505 City Blvd', 'Metrocity', 'urbanescape.jpg', 'room8.jpg', 'Rooftop Bar, Gym', 3, 3.9);

update hotel
set hotel_phone=Case
	when hotel_id=1 then 9876543210
    when hotel_id=2 then 9867452314
    when hotel_id=3 then 9182736451
    when hotel_id=4 then 9966225612
    when hotel_id=5 then 9123456789
end
where hotel_id in (1,2,3,4,5);
select * from hotel;

update hotel
set hotel_description=case
	when hotel_id=3 then "Nice hotel"
    when hotel_id=4 then "Good hotel"
end
where hotel_id in (3,4);
select * from hotel;

Replace into hotel values
(5,"IOS Rahmos","rahmos@infy.com",9999999999,"10,Park Road,Bangalore","Bangalore","images\\5.jpg","image\\5.jpg","A.C.#Swimming Pool#Breakfast#Gym",5,5.0,"Spacious Rooms","Room Service is Bad",null);
select * from hotel;

-- delete 
-- from hotel
-- where lower(hotel_name)=lower("Park Adission");
delete
from hotel
where lower(hotel_name)=lower("Desert Oasis");
