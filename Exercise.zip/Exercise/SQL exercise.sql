select h.hotel_name
from hotel as h join hotel_room_details as hr
on h.hotel_id=hr.hotel_id
where lower(hr.room_type)=lower("deluxe room ac");

select sum(hr.room_price), h.hotel_name
from hotel_room_details as hr inner join hotel as h
on hr.hotel_id=h.hotel_id
group by h.hotel_name;

select count(b.booking_user_email)
from booking as b inner join user_details as u
on u.user_email=b.booking_user_email
where lower(u.user_name)="john";

select count(h.hotel_id),h.hotel_name
from hotel_room_details as hr join hotel as h
on h.hotel_id=hr.hotel_id
where hr.room_price<10000
group by h.hotel_id;

select h.hotel_name
from hotel as h
where h.hotel_id not in (
	select h.hotel_id
	from booking as b join hotel_room_details as h
    on b.booking_room_id=h.room_id
);
select * from hotel;