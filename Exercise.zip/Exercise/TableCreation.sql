create schema exercise;
use exercise;
Drop Table If Exists Booking;
Drop Table If Exists Hotel_Room_Details;
Drop Table If Exists Hotel;
Drop Table If Exists User;

Create Table User(
    User_email varchar(50) Primary Key,
    User_name varchar(50),
    User_phone bigint,
    User_password varchar(50)
)Engine=InnoDB Default Charset=latin1;

Insert Into user Values
("mark.casperstay@gmail.com","Mark",9832158798,"Mark@123"),
("john.casperstay@gmail.com","John",9876543212,"John@123");

Drop Table If Exists Hotel;

Create Table Hotel(
    Hotel_id int primary key,
    Hotel_name varchar(50),
    Hotel_email varchar(50),
    Hotel_phone bigint,
    Hotel_address varchar(250),
    Hotel_city varchar(250),
    Hotel_image varchar(250),
    Hotel_room_image varchar(250),
    Hotel_amenities varchar(250),
    Hotel_stars int,
    Hotel_ratings_avg decimal(2,1),
    Hotel_pcomments text,
    Hotel_ncomments text,
    Hotel_description text
)Engine=InnoDb Default Charset=latin1;

Insert Into Hotel Values
(1,"The phoenix","phoenix.abc@gmail.com",9875698756,"1318,Vinoba Rd,Delhi-570026","Delhi","image1.png","image123.png","A.C.#Swimming Pool#Breakfast#Pickup#SideScene",3,4.5,null,null,null),
(2,"Luna Crystal","luna.xyz@gmail.com",9884498844,"1, MG Road, Mysuru","Mysuru","image2.png","image234.png","A.C.#Swimming Pool#Breakfast#Pickup#",4,3.5,null,null,null),
(3,"Vega Polaris","polaris.def@gmail.com",9765976555,"10,Park road,Goa","Goa","image3.png","image345.png","A.C.#Swimming Pool#Gym",3,0,null,null,null);

Drop Table If Exists Hotel_Room_Details;

Create Table Hotel_Room_Details(
    Room_id int primary key,
    Room_type varchar(50),
    Room_price int,
    Hotel_id int,
    Foreign Key(Hotel_id) References Hotel(Hotel_id)
)Engine=InnoDb Default Charset=latin1;

Insert Into Hotel_Room_Details Values
(1000,"Double Room AC",10000,1),
(1001,"Single Room",5000,1),
(1002,"Deluxe Room",14000,1),
(1003,"Deluxe Room AC",14900,1),
(1090,"Double Room AC",9000,2),
(1091,"Single Room",4000,2),
(1092,"Deluxe Room",12000,2),
(2000,"Double Room AC",9000,3),
(2001,"Deluxe Room AC",14900,3);

Drop Table If Exists Booking;
Create Table Booking(
    Booking_id int,
    Booking_room_id int,
    Booking_user_email varchar(50),
    Booking_checkin Date,
    Booking_checkout Date,
    Booking_room_price int,
    Booking_room_rating int,
    Booking_room__pcomments varchar(250),
    Booking_room_ncomments varchar(250),
    Constraint Booking_pk Primary Key(Booking_id),
    Constraint FKEYBRI Foreign Key(Booking_room_id)
    References Hotel_Room_Details(Room_id),
    Constraint FKEYBUE Foreign Key(Booking_user_email)
    References User(User_email)
)Engine=InnoDB Default Charset=latin1;

Insert Into Booking Values
(101,1002,"john.casperstay@gmail.com","2016-02-13","2016-02-14",14000,4,"Good ambience and maintanance",null),
(102,1090,"mark.casperstay@gmail.com","2017-09-22","2017-09-23",9000,3.5,null,null),
(103,1000,"john.casperstay@gmail.com","2017-09-22","2017-09-23",10000,5,null,null);

alter table user add column user_role varchar(50) after user_phone;

drop table if exists booking_logs;
create table booking_logs(
    booking_id int not null,
    booking_room_id int not null,
    booking_user_email varchar(50),
    Booking_checkin Date,
    Booking_checkout Date,
    Booking_room_price int,
    Booking_room_rating int,
    Booking_room__pcomments varchar(250),
    Booking_room_ncomments varchar(250),
)   Engine=InnoDB Default Charset=latin1;

alter table booking_logs add constraint foreign key(booking_user_email) references user(user_email);
alter table user rename user_details;
alter table booking_logs change booking_room_ncomments booking_room__ncomments text;
alter table booking_logs drop booking_room_rating;